from django.contrib import admin
from note.models import Note
# Register your models here.

admin.site.register(Note)
