from django.contrib import admin
from .models import Data,Nominal,Approval

# Register your models here.


class DataAdmin(admin.ModelAdmin):
    list_display = ('country', 'latitude', 'longitude')


admin.site.register(Data, DataAdmin)
admin.site.register(Nominal)
admin.site.register(Approval)