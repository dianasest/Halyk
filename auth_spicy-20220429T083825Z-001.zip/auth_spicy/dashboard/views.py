from django.shortcuts import render
from .models import Data
import folium
from folium import plugins
import base64
from io import BytesIO
# Create your views here.


def Map(request):
    data = Data.objects.all()
    data_list = Data.objects.values_list('latitude', 'longitude')
    adress_list = Data.objects.values_list('country')
    map1 = folium.Map(location=[42.8746, 74.5698], zoom_start=13)
    
    for i in range(0,len(data_list)):
        folium.Marker(
            location=[data_list[i][0], data_list[i][1]],
            popup=f"<p>АДРЕС:{adress_list[i]}</p><p>наличие денег:10000</p><p>РЕЖИМ РАБОТЫ: 9.00 до 17.30</p><a href='http://127.0.0.1:8000/application/' target='_blank'><button style='background-color:green;color:white;outline:none;'>ОТПРАВИТЬ ЗАЯВКУ</button></a>",
            icon=folium.Icon(icon='magnet', prefix='fa', color='green')).add_to(map1)

    map1 = map1._repr_html_()
    context = {
        'map1': map1,
    }
    return render(request, 'map.html', context)

def Table(request):
    atms = Data.objects.all() 
    context = {
    'atms':atms,
    }
    return render(request, "table.html", context)

def Home(request):
    countFilled = len(Data.objects.filter(filled=True))
    print(countFilled)
    countEmpty = len(Data.objects.filter(filled=False))
    print(countEmpty)
    context = {
        'countFilled':countFilled,
        'countEmpty':countEmpty,
    }
    return render(request,"home.html",context)

def Application(request):
    
    return render(request,"login1.html")

def Approval(request):
    return render(request,"approval.html")
