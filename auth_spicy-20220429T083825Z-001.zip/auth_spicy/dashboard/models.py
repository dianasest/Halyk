from django.db import models
import geocoder

# Create your models here.


class Data(models.Model):
    country = models.CharField(max_length=100, null=True,blank=True, verbose_name="Адрес Банкомата")
    latitude = models.FloatField(default=0, null=True,blank=True)
    longitude = models.FloatField(default=0, null=True,blank=True)
    balance = models.IntegerField(default=10000)
    filled = models.BooleanField(default=False)
    class Meta:
        verbose_name_plural = 'Data'

    def save(self, *args, **kwargs):
        self.latitude = geocoder.osm(self.country).lat
        self.longitude = geocoder.osm(self.country).lng
        return super().save(*args, **kwargs)

    def __str__(self):
        return self.country
class Nominal(models.Model):
    data = models.ForeignKey(Data, on_delete=models.CASCADE, blank=True, null=True)
    hundred = models.IntegerField(verbose_name='100',default =0)
    twohundred = models.IntegerField(verbose_name='200',default =0)
    fivehundred = models.IntegerField(verbose_name='500',default =0)
    thousand = models.IntegerField(verbose_name='1000',default=0)

    def __str__(self):
        return self.data

class Approval(models.Model):
    data = models.ForeignKey(Data, on_delete=models.CASCADE, blank=True, null=True)
    name  = models.CharField(max_length=100,null=True,blank=True)
    summa = models.CharField(max_length=100,null=True,blank=True)
    date = models.DateField(auto_now_add=True)
    approve = models.BooleanField()

    def __str__(self):
        return self.data